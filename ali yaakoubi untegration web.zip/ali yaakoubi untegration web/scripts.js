function ajouterAuPanier(titre, auteur, prix) {
    // Créer un objet livre avec les informations
    const livre = {
        titre: titre,
        auteur: auteur,
        prix: prix,
    };

    // Récupérer le panier actuel ou créer un panier vide
    let panier = JSON.parse(localStorage.getItem("panier")) || [];

    // Ajouter le livre au panier
    panier.push(livre);

    // Sauvegarder le panier dans le localStorage
    localStorage.setItem("panier", JSON.stringify(panier));

    // Rediriger l'utilisateur vers la page panier.html
    window.location.href = "panier.html";
}
